
### Download Tutorial Dataset ######
from <- "https://github.com/bpollner/data/raw/main/myLFS/flowdexTutorial.zip"
destination <- "~/desktop"
targetZip <- paste0(destination, "/flowdexTutorial.zip")
download.file(from, targetZip, mode="wb")
unzip(targetZip, exdir = destination)


### Initialise Settings File System ###
library(flowdex)
setupSettings(destination)
# possibly restart R



### Quckstart ###
# If you want to immediately see what flowdex can do:
destination <- "~/desktop" # again, as R was possibly restarted
setwd(paste0(destination, "/flowdexTutorial"))
library(flowdex)
fdmat <- flowdexit() # this might take a few seconds
fdmat@pData # to inspect volume and sample ID data
fdmat@cyTags # to inspect class- and numerical variables assigned to each sample
fdmat[[1]] # to inspect fluorescence distribution



### create home-folder and folder structure #####
destination <- "~/desktop" # again, as R was possibly restarted
expHome <- paste0(destination, "/tapWater@home")
dir.create(expHome)
setwd(expHome)
library(flowdex) # as you might have had to restart R above
genfs() # is generating the required folder structure within "tapWater@home"

## now would be data acquisition

# move or copy fcs files
from <- list.files(paste0(destination, "/flowdexTutorial/fcsFiles"), full.names = TRUE)
to <- paste0(destination, "/tapWater@home/fcsFiles")
file.copy(from, to, overwrite = TRUE)

# move or copy dictionary
from <- list.files(paste0(destination, "/flowdexTutorial/dictionary"), full.names = TRUE)
to <- paste0(destination, "/tapWater@home/dictionary")
file.copy(from, to, overwrite = TRUE)


## make Gating Set and plot ##
gsAll <- makeGatingSet()

gsRed <- makeGatingSet(patt="GPos_T6_th2")
gsRed


plotgates(gsRed, toPdf = FALSE, x="FITC.A", y="PerCP.A")


## draw gates ##
drawGate(gsRed, flf=7, gn="root", pggId="BactStainV1", channels=".")
# point and click to draw a polygon gate around the population of interest

# draw again
drawGate(gsRed, flf=7, gn="root", pggId="BactStainV1", show="BactStainV1")


# copy BactStainV1 from tutorial
from <- paste0(destination, "/flowdexTutorial/gating/BactStainV1")
to <- paste0(destination, "/tapWater@home/gating")
file.copy(from, to, overwrite = TRUE)


# copy gating strategy template
from <- paste0(destination, "/tapWater@home/templates/gateStrat.xlsx")
to <- paste0(destination, "/tapWater@home/gating")
file.copy(from, to)

# copy the gating strategy
from <- paste0(destination, "/flowdexTutorial/gating/gateStrat.xlsx")
to <- paste0(destination, "/tapWater@home/gating")
file.copy(from, to, overwrite=TRUE)

# ad gate to gsRed
gsRed_ga <- addGates(gsRed)
flowWorkspace::plot(gsRed_ga) # to view the gate hierarchy
plotgates(gsRed_ga, toPdf = FALSE) # to view the gated data



# second iteration
drawGate(gsRed_ga, flf=7, gn="DNA+", pggId="pg2", channels = c("FITC.A", "SSC.A"))
# point and click to draw a polygon gate around the population of interest

# add the gate in the gating strategy:
#GateName	Parent		GateOnX		GateOnY		GateDefinition		extractOn	minRange	maxRange	keepData
#FooGate		DNA+		FITC.A		SSC.A		pg2					SSC.A		0			4000		TRUE

gsRed_ga <- addGates(gsRed_ga) # add the gate to the gating set
flowWorkspace::plot(gsRed_ga) # visualise gating hierarchy
plotgates(gsRed_ga, toPdf = F)



## copy gating strategy 2
from <- list.files(paste0(destination, "/flowdexTutorial/gating"), full.names = TRUE)
to <- paste0(destination, "/tapWater@home/gating")
file.copy(from, to, overwrite=TRUE) # this might overwrite the polygon gate definition you created above

# and make again reduced gating set
gsRed2 <- makeAddGatingSet(patt="GPos_T6_th2", gateStrat = "gateStrat_2")
flowWorkspace::plot(gsRed2) # to view the gating hierarchy
plotgates(gsRed2, toPdf = F) # to view the gated data

